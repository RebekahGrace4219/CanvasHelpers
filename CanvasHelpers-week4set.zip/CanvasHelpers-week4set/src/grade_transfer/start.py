# Author: Qianhan Zhang


from src.grade_transfer.user_interface import UserInterface
import canvasapi
from src.grade_transfer.canvas_grade_transfer import CanvasGradeTransfer

UI = UserInterface()

