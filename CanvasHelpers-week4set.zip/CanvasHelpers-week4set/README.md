# CanvasHelpers
A collection of useful applications for doing things Canvas can't do natively


1. Each time the program is run, the follow needs to enter the following:
  APIKEY : personal API key
  CLASS_ID : the unique class number (you can see it in the url if you navigate to the class)
  QUIZ_ID: the quiz's identification (you can see it in the url if you navigate to the quiz)
  className: the name of the class you are evaluating
  studyGroupNumber: the number study group you are on, in int form
  
2. If ever moved from ECS 036A and ECS 154A, the quiz numbers in the parser will need to be updated and possibly the questions themselves
